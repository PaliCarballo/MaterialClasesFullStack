# Digital Movies

##Primero debes restaurar la BD en el archivo restaurar.sql

###Editar el archivo conexion.php con las credenciales de tu mysql.
